package residentevil.domain.entities;

public enum Magnitude {

    Low, Medium, High;
}
